app_ui <- function(request) {
  required_packages <- c("shinyFiles", "shinyjs", "tidyverse", "dplyr", "tidyr")
  for (package in required_packages) {
    if (!require(package, character.only = TRUE)) {
      install.packages(package, dependencies = TRUE)  # 安装缺失的包
      library(package, character.only = TRUE)         # 加载包
    } else {
      library(package, character.only = TRUE)         # 如果已安装，直接加载包
    }
  }
  library(shinyFiles)  # 加载 shinyFiles 包
  library(shinyjs)     # 用于显示和隐藏气泡提示
  library(tidyverse)
  library(dplyr)
  library(tidyr)
  shiny::addResourcePath("www",paste0(.libPaths()[1],'/','LipidINqual/www'))
  dashboardPage(
    dashboardHeader(
      title = tags$div(
        tags$img(src="www/logo.png",height="30px",style="margin-right: 0px;"),"LipidIN"),
      titleWidth = 200  # 调整宽度以适应 Logo 和标题
    ),
    dashboardSidebar(
      sidebarMenu(
        menuItem("Compound Annotation", tabName = "an", icon = icon("flask")),
        menuItem("Annotation for EAD", tabName = "ead", icon = icon('atom'))
      )
    ),
    dashboardBody(
      useShinyjs(),  # 启用 shinyjs
      tags$style(HTML("
        /* 确保标题底色为清华紫色 */
        .main-header {
          background-color: #722872 !important;
        }
        .logo {
          color: white !important;
        }
        .main-header .logo {
          background-color: #722872 !important;
        }
        .main-header .navbar {
          background-color: #722872 !important;
        }
        .box-header {
          background-color: #722872 !important;
          border-bottom: 2px solid #722872 !important;
        }
        .box-title {
          color: white !important;
          font-weight: bold;
        }
        .box {
          border: 2px solid #722872 !important;
          border-radius: 5px !important;
        }
        .box-footer {
          border-top: 2px solid #722872 !important;
        }
        .content-wrapper {
          background-color: #f4f6f9 !important;
        }
        .main-sidebar {
          background-color: #222d32 !important;
        }
        .sidebar-menu li a {
          font-weight: bold !important;
        }
        .logo {
          font-weight: bold !important;
        }
        .sidebar-menu li.active {
          background-color: #f3e5f5 !important;
        }
        .sidebar-menu li.active > a {
          border-left: 16px solid #722872 !important;
          padding-left: 20px !important;
        }
        #start_button {
          background-color: #722872 !important;
          color: white !important;
          font-weight: bold !important;
          width: 100px;
          margin-left: auto;
          margin-right: auto;
          display: block;
          padding: 10px 20px;
        }
        #start_button2 {
          background-color: #722872 !important;
          color: white !important;
          font-weight: bold !important;
          width: 100px;
          margin-left: auto;
          margin-right: auto;
          display: block;
          padding: 10px 20px;
        }
        #start_button_ead {
          background-color: #722872 !important;
          color: white !important;
          font-weight: bold !important;
          width: 100px;
          margin-left: auto;
          margin-right: auto;
          display: block;
          padding: 10px 20px;
        }
        #start_button_pb {
          background-color: #722872 !important;
          color: white !important;
          font-weight: bold !important;
          width: 100px;
          margin-left: auto;
          margin-right: auto;
          display: block;
          padding: 10px 20px;
        }
        #view_button {
          background-color: #722872 !important;
          color: white !important;
          font-weight: bold !important;
          width: 80px;
          margin-left: auto;
          margin-right: auto;
          display: block;
          padding: 10px 20px;
        }
        .watermark {
          position: fixed;
          bottom: 10px;
          right: 10px;
          opacity: 0.3;
          z-index: 1;
        }
      ")),
      tabItems(
        tabItem(tabName = "an",
                fluidRow(
                  column(12,
                         box(
                           title = "Compound Annotations", status = "info", solidHeader = TRUE, width = 12,
                           textInput("folder_path", "Folder Path", value = "", placeholder = "e.g., D:/mzML_Files"),
                           textInput("rda_file", "Enter the Full Path of the File", placeholder = "e.g., C:/Users/YourName/Documents/library_positive.rda"),
                           numericInput("abundance_filter", "Abundance Filter (0-1)", value = 0.05, min = 0, max = 1, step = 0.01),
                           selectInput("ion_mode", "Ionization Mode", choices = c("Positive Ion Mode", "Negative Ion Mode (Formate)", "Negative Ion Mode (Acetate)")),
                           numericInput("ms1_tolerance", "MS1 Tolerance (ppm)", value = 5, min = 0, max = 100, step = 1),
                           numericInput("ms2_tolerance", "MS2 Tolerance (ppm)", value = 20, min = 0, max = 100, step = 1),
                           actionButton("start_button", "Start", icon = icon("play"))
                         )
                  )
                ),
                tags$img(src = "www/logo.png", class = "watermark", width = "150px")  # 水印图片
        ),
        tabItem(tabName = "ead",
                fluidRow(
                  column(12,
                         box(
                           title = "Annotation for Electron activated dissociation (EAD)", status = "info", solidHeader = TRUE, width = 12,
                           textInput("folder_path_ead", "Folder Path", value = "", placeholder = "e.g., D:/mzML_Files"),
                           textInput("rda_file_ead", "Enter the Full Path of the File", placeholder = "e.g., C:/Users/YourName/Documents/library_positive.rda"),
                           numericInput("abundance_filter_ead", "Abundance Filter (0-1)", value = 0.01, min = 0, max = 1, step = 0.01),
                           selectInput("ion_mode_ead", "Ionization Mode", choices = c("Positive Ion Mode")),
                           numericInput("ms1_tolerance_ead", "MS1 Tolerance (ppm)", value = 5, min = 0, max = 100, step = 1),
                           numericInput("ms2_tolerance_ead", "MS2 Tolerance (ppm)", value = 20, min = 0, max = 100, step = 1),
                           actionButton("start_button_ead", "Start", icon = icon("play"))
                         )
                  )
                ),
                tags$img(src = "www/logo.png", class = "watermark", width = "150px")  # 水印图片
        )


      )
    )
  )
}
# app_server <- function(input, output, session) {}
# shinyApp(ui=app_ui,server=app_server)
# library(this.path)
# library(shinyjs)
# library(RaMS)
# library(Rcpp)
# library(tidyverse)
# library(dplyr)
# library(shiny)
# library(golem)
# library(shinydashboard)
# library(ggplot2)
# library(ggforce)
# library(magick)
# library(grid)
# library(tidyr)
# library(shinyFiles)
