run_LipidIN <- function(options = list()) {
  shiny::shinyApp(ui = app_ui, server = app_server,options = options)
}
