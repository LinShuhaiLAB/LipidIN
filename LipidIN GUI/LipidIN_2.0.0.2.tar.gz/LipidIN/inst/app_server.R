app_server <- function(input, output, session) {
  library(shinyFiles)  # 加载 shinyFiles 包
  library(shinyjs)     # 用于显示和隐藏气泡提示
  library(tidyverse)
  library(dplyr)
  library(tidyr)
  FKBC <- paste0(.libPaths(),'/','LipidIN')
  options(warn = -1)
  options(warning.expression = {
    if (grepl("Scale for fill is already present", geterrmessage())) {
      invokeRestart("muffleWarning")  # 忽略该警告
    }
  })

  params <- reactiveValues(folder_path = NULL, mzml_files = NULL, rda_file = NULL,
                           LCI_rt=NULL)  # 用于存储动态参数

  # 保存原始 message 函数
  original_message <- base::message

  # 重写 message 函数
  message <- function(...) {
    cat("\033[32m")  # 设置绿色
    original_message(...)  # 调用原始的 message 函数
    cat("\033[0m")  # 重置颜色
  }
  # 定性一
  {
    # 监听文件夹路径输入
    observeEvent(input$folder_path, {
      folder <- input$folder_path  # 获取用户输入的路径
      if (dir.exists(folder)) {
        params$folder_path <- folder  # 保存有效的文件夹路径
        # 查找 .mzML 文件
        mzml_files <- list.files(folder, pattern = "\\.mzML$", full.names = TRUE)
        params$mzml_files <- mzml_files
        output$selected_folder <- renderText({
          paste("Selected folder:", folder, "\nFound .mzML files:", length(mzml_files))
        })
        message("Valid folder selected: ", folder, " with ", length(mzml_files), " .mzML files.")
      } else {
        params$folder_path <- NULL
        params$mzml_files <- NULL
        output$selected_folder <- renderText("Invalid folder path. Please check and try again.")
        message("Invalid folder path: ", folder)
      }
    })

    # 输出选中的文件夹路径
    output$selected_folder <- renderText({
      if (!is.null(params$folder_path)) {
        paste("Selected folder: ", params$folder_path, "\nFound .mzML files: ", length(params$mzml_files))
      } else {
        "No folder selected"
      }
    })

    # 监听 .rda 文件上传
    observeEvent(input$rda_file, {
      req(input$rda_file)  # 确保文件已上传
      params$rda_file <- input$rda_file  # 存储上传文件的路径
      message("Uploaded .rda file: ", input$rda_file)
    })
    observeEvent(input$LCI_rt, {
      req(input$LCI_rt)  # 确保文件已上传
      params$LCI_rt <- input$LCI_rt  # 存储上传文件的路径
      message("Uploaded .rda file: ", input$LCI_rt)
    })


    # 监听开始按钮点击事件
    observeEvent(input$start_button, {
      # 验证所有输入参数
      showNotification("Verify if all the required R packages are installed.",type="message",duration=360)
      required_packages <- c("shinyFiles", "shinyjs", "tidyverse", "dplyr", "tidyr")

      # 自动检查并安装缺失的包
      for (package in required_packages) {
        if (!require(package, character.only = TRUE)) {
          install.packages(package, dependencies = TRUE)  # 安装缺失的包
          library(package, character.only = TRUE)         # 加载包
        } else {
          library(package, character.only = TRUE)         # 如果已安装，直接加载包
        }
      }
      library(shinyFiles)  # 加载 shinyFiles 包
      library(shinyjs)     # 用于显示和隐藏气泡提示
      library(tidyverse)
      library(dplyr)
      library(tidyr)
      library(RaMS)
      req(params$folder_path, params$mzml_files, params$rda_file)
      req(input$abundance_filter, input$ion_mode, input$ms1_tolerance, input$ms2_tolerance)
      showNotification("Waiting for package loading...",type="message",duration=360)
      setwd(paste0(.libPaths(),'/','LipidIN'))
      source(paste('p1.R',sep=''))
      # source(paste('pathway.R',sep=''))
      sourceCpp(paste('EQ.cpp',sep=''))
      sourceCpp(paste('EQ_support.cpp',sep=''))
      sourceCpp(paste('calculateMolecularMass.cpp',sep=''))
      sourceCpp(paste('rawmzcluster.cpp',sep=''))
      sourceCpp(paste('removeRowsWithinError.cpp',sep=''))
      sourceCpp(paste('sortMatrixByRow.cpp',sep=''))
      # 设置工作目录到选择的文件夹
      setwd(params$folder_path)
      showNotification(paste0("Working directory set to: ", params$folder_path),type="message",duration=360)


      # 显示任务状态提示
      shinyjs::show("status_bubble")
      shinyjs::html("status_bubble", "Processing... Please wait.")
      # 遍历 .mzML 文件并处理
      for (ii in params$mzml_files) {
        message("Processing file: ", ii,' ESI: ',input$ion_mode,' MS2 filter: ',input$abundance_filter)
        tryCatch({
          # 假设 part1_RaMS 支持直接处理路径
          # part1_RaMS(ii,
          #            ESImode = input$ion_mode,
          #            MS2_filter = input$abundance_filter)
          FN1 <- ii
          ESImode = input$ion_mode
          MS2_filter = input$abundance_filter
          library(RaMS)
          library(dplyr)
          cat("\033[32mgrabMzmlData reading MS2!\n\033[0m")
          a <- grabMzmlData(FN1,grab_what=c("MS2"))
          cat("\033[32mReading MS2 done!\n\033[0m")
          a <- a$MS2
          a$row_id <- 1:nrow(a)
          nrow.count <- a %>% group_by(rt,premz) %>% summarise(row_numbers=list(row_id),.groups='drop')
          nrow.count <- nrow.count %>% mutate(row_numbers=sapply(row_numbers,function(x) paste(x,collapse=", ")))
          cat("\033[32mRefactor the data structure!\n\033[0m")
          rr <- lapply(1:nrow(nrow.count),function(i){
            rrr <- unlist(nrow.count[i,3]) %>% strsplit(", ") %>% unlist() %>% as.numeric()
            c <- a[rrr,]
            count.1 <- list(
              num=i,
              PrecursorMZ=as.numeric(c[1,2]),
              PrecursorIntensity=1,
              mode=ESImode,
              rt=as.numeric(c[1,1]),
              MS2mz=data.frame(da.temp.mz=c[,3],da.temp.intensity=c[,4])
            )
            aa <- count.1$MS2mz
            colnames(aa) <- c('da.temp.mz','da.temp.intensity')
            aa <- aa[which(aa$da.temp.intensity>MS2_filter*max(count.1$MS2mz[,2])),]
            count.1$MS2mz <- aa
            return(count.1)
          })
          neg.list <- do.call(list,rr)
          file3 <- paste(gsub('.mzML','',FN1),'_treated.rda',sep='')
          save(neg.list,file=file3)
          cat("\033[32mDONE!!!!!!\n \033[0m")
          showNotification(paste0("Successfully processed file: ", ii),type="message",duration=360)
        }, error = function(e) {
          showNotification(paste0("Error processing file: ", ii),type="error",duration=360)
        })
      }

      # 加载谱库
      shinyjs::show("status_bubble")
      shinyjs::html("status_bubble", "Reading Spectral Library... Please wait.")
      showNotification("Loading spectral library...",type="message",duration=360)
      tryCatch({
        load(params$rda_file)  # 加载 .rda 文件
        showNotification("Successfully loaded spectral library.",type="message",duration=360)
        cat("\033[32mSuccessfully loaded spectral library.\n \033[0m")
      }, error = function(e) {
        showNotification("Error loading spectral library.",type="message",duration=360)
      })

      ESI <- input$ion_mode
      if(length(grep("OAc",ESI))==1){
        ESI <- 'n2'
      }
      if(length(grep("HCOO",ESI))==1){
        ESI <- 'n1'
      }
      if(ESI=="Positive Ion Mode"){
        ESI <- 'p'
      }
      pt <- paste0(.libPaths(),'/','LipidIN')
      if(ESI=='p'){
        source(paste(pt,'/p2.r',sep=''))
      }
      if(ESI!='p'){
        if(ESI=='n1'){
          source(paste(pt,'/p2COOH.r',sep=''))
        }
        if(ESI=='n2'){
          source(paste(pt,'/p2CH3COO.r',sep=''))
        }
      }
      FN1 <- list.files()
      FN1 <- FN1[grep('.rda',FN1)]
      compare <- new(Comparator)
      ppm1 <- input$ms1_tolerance
      ppm2 <- input$ms2_tolerance
      compare$Load(NULL,count.data.frame$MZ,ppm1,ppm2,count.list)
      message("Output file name: ",params$folder_path)
      setwd(params$folder_path)
      showNotification("Starting MS2 querting...",type="message",duration=360)
      for(ii in FN1){
        print(ii)
        FNIII <- ii
        cat("\033[32m",paste('Match files ',FNIII,sep=''),"\n\033[0m")
        load(FNIII)
        cat("\033[32m",paste('Success load ',FNIII,sep=''),"\n\033[0m")
        sample_mz <- purrr::map(.x=neg.list, .f=function(x){
          return(x$PrecursorMZ)
        }) %>% unlist()
        neg.list <- neg.list[order(sample_mz)]
        neg.list <- lapply(1:length(neg.list), function(i){
          neg.list[[i]][["num"]] <- as.character(neg.list[[i]][["num"]])
          return(neg.list[[i]])
        })
        # NPG-MS2 --------------------------------------------------------------------
        # 构造函数
        # compare <- new(Comparator)
        # # 加载数据
        # # par-1:sample_list , par-2:library_mz , par-3:ms1_ppm , par-4:ms2_ppm , par-5:library_list
        # compare$Load(neg.list,count.data.frame$MZ,ppm1,ppm2,count.list)
        compare$Load2(neg.list,ppm1,ppm2)
        # 比较谱图
        compare$Compare()
        # 输出csv文件
        compare$OutputCsv(paste(gsub('.rda','',FNIII),'_NPG_5ppm.csv',sep=''))
        part2(ii)
      }
      if(input$LCI_rt=="MS1 Rt"){
        showNotification("Waiting for XCMS peak detection...",type="message",duration=360)
        rm(count.data.frame,count.list)
        library(xcms)
        library(tidyverse)
        library(CAMERA)
        # 遍历 .mzML 文件并处理
        for (ii in params$mzml_files) {
          showNotification(paste0("Starting picking peak ",ii),type="message",duration=360)
          message("XCMS Processing file: ", ii)
          FN1 <- ii
          cat("\033[32mXCMS picking peak reading MS2!\n\033[0m")
          filename=FN1
          # filename <- 'NIST_Iterative_20ev_1_NEG.mzML'
          message("Reaing...")
          data_prof_inmemory <- readMSData(filename,mode="onDisk",centroided=F,smoothed.=F,msLevel.=c(1))
          message("Done!")
          # 利用centWave算法进行峰检测
          cwp <- CentWaveParam(peakwidth=c(as.numeric(input$peakwidth_left),as.numeric(input$peakwidth_right)),
                               noise=as.numeric(input$noise))
          xdata <- findChromPeaks(data_prof_inmemory,param=cwp,return.type='xcmsSet')

          an <- xsAnnotate(xdata)# 将 xcmsSet 对象转换为 CAMERA 的 xsAnnotate 对象
          an <- groupFWHM(an)# 分组峰（基于保留时间）
          an <- findIsotopes(an)# 查找同位素峰
          deisotoped_peaks <- getPeaklist(an)# 提取去同位素后的峰表
          deisotoped_peaks <- deisotoped_peaks[-grep('M\\+',deisotoped_peaks$isotopes),]
          peak <- deisotoped_peaks %>% as.data.frame()
          result <- cbind(peak$mz,peak$into,peak$rt) %>% `colnames<-`(c("mz","intensity","rt"))
          result <- as.data.frame(result)
          result$mz <- round(result$mz,4)
          result$intensity <- round(result$intensity,2)
          result$rt <- result$rt/60
          write.csv(x = result , row.names = FALSE,
                    file=paste(gsub('.mzML','',filename),'_peaks.csv',sep=''))
          cat("\033[32mpicking peak done!\n\033[0m")
          # FN1 <- 'D:/bio_inf/LipidINDesk/XCMS/test/NIST_Iterative_40ev_2_NEG.mzML'
          peak_data <- read.csv(paste(gsub('.mzML','',FN1),'_peaks.csv',sep=''))
          pc_data <- read.csv(paste(gsub('.mzML','',FN1),'_treated_NPG_processed.csv',sep=''))
          r <- lapply(1:nrow(pc_data),function(pci){
            rt1 <- which(abs(pc_data[pci,]$rt-peak_data$rt)<=0.5)
            mz1 <- which(abs(pc_data[pci,]$mz-peak_data$mz)<=0.02|
                         abs(pc_data[pci,]$mz-peak_data$mz)/pc_data[pci,]$mz<=10^-5)
            intersitymzrt <- intersect(rt1,mz1)
            if(length(intersitymzrt)==1){
              pc_data[pci,]$mz <- peak_data[intersitymzrt,]$mz
              pc_data[pci,]$rt <- peak_data[intersitymzrt,]$rt
              pc_data[pci,]$rt <- round(pc_data[pci,]$rt,2)
              return(pc_data[pci,])
            }
            if(length(intersitymzrt)>1){
              # print(pci)
              rt2 <- which.min(abs(pc_data[pci,]$rt-peak_data[intersitymzrt,]$rt))[1]
              pc_data[pci,]$mz <- peak_data[intersitymzrt[rt2],]$mz
              pc_data[pci,]$rt <- peak_data[intersitymzrt[rt2],]$rt
              return(pc_data[pci,])
            }
          })
          r <- do.call(rbind,r)
          write.csv(r,paste(gsub('.mzML','',FN1),'_treated_NPG_processed.csv',sep=''),row.names = F)
          showNotification(paste0("Successfully processed file: ", ii),type="message",duration=360)
        }
        showNotification("Starting LCI retention time prediction and judgment...",type="message",duration=360)
        source(paste(pt,'/LCI.r',sep=''))
        a <- Sys.time()
        env <- new.env()
        FN1 <- list.files()
        FN1 <- FN1[grep('.rda',FN1)]
        setwd(pt)
        for(ii in FN1){
          print(ii)
          showNotification(paste(input$folder_path,'/',ii,sep=''),type="message",duration=360)
          LCI(paste(input$folder_path,'/',ii,sep=''))
          setwd(pt)
        }
        Sys.time()-a
        setwd(input$folder_path)
        a <- list.files()
        b <- a[grep('.csv',a)]
        b <- b[-grep('final_output.csv',b)]
        file.remove(b)
      }
      if(input$LCI_rt=="MS2 scan time"){
        showNotification("Skip the peak detection step",type="message",duration=360)
        showNotification("Starting LCI retention time prediction and judgment...",type="message",duration=360)
        source(paste(pt,'/LCI.r',sep=''))
        rm(count.data.frame,count.list)
        a <- Sys.time()
        env <- new.env()
        setwd(pt)
        for(ii in FN1){
          print(ii)
          showNotification(paste(input$folder_path,'/',ii,sep=''),type="message",duration=360)
          LCI(paste(input$folder_path,'/',ii,sep=''))
          setwd(pt)
        }
        Sys.time()-a
        setwd(input$folder_path)
        a <- list.files()
        b <- a[grep('.csv',a)]
        b <- b[-grep('final_output.csv',b)]
        file.remove(b)
      }
      # 合并注释结果
      showNotification("Merge all annotations.",type="message",duration=360)
      message("Merge all annotations.")
      # setwd('D:/bio_inf/LipidINDesk/XCMS/test')
      setwd(input$folder_path)
      a <- list.files()
      b <- a[grep('.csv',a)]
      if(length(b)>1){# 多余一个才合并
        b <- lapply(1:length(b),function(bi){
          bb <- read.csv(b[bi])
          bb$file.name <- gsub('_final_output.csv','',b[bi])
          return(bb)
        })
        b2 <- do.call(rbind,b)
        # 提取唯一的mz、rt
        b2 <- b2[,c('mz','rt')]
        b2$rt <- round(b2$rt,2)
        b2 <- b2[!duplicated(b2),]
        b3 <- lapply(1:length(b), function(bi){
          data <- b[[bi]]
          bib3i <- lapply(1:nrow(b2),function(b3i){
            rt <- b2[b3i,]$rt
            mz <- b2[b3i,]$mz
            mz_k1 <- which(abs(mz-data$mz)<=0.01|abs(mz-data$mz)/data$mz<=10^-5)
            rt_k1 <- which(abs(rt-data$rt)<=0.15)
            k1 <- intersect(mz_k1,rt_k1)
            if(length(k1)==0){
              return(0)
            }
            if(length(k1)==1){
              return(data[k1,]$Title)
            }
            if(length(k1)>1){
              m <- data[k1,]
              m <- m[order(m$final.score,decreasing=T),]
              return(paste(m$Title,collapse=' or '))
            }
          })
          bib3i <- do.call(rbind,bib3i)
        })
        b3 <- do.call(cbind,b3)
        b3 <- as.data.frame(b3)
        a <- list.files()
        b <- a[grep('.csv',a)]
        colnames(b3) <- gsub('_final_output.csv','',b)
        b23 <- cbind(b2,b3)
        write.csv(b23,'Merged annotations.csv',row.names=F)
      }
      # 做定量
      library(xcms)
      library(pracma)  # 用于梯形积分
      setwd(input$folder_path)
      user_peaks <- read.csv('Merged annotations.csv')
      user_peaks <- data.frame(mz=user_peaks$mz,rt=user_peaks$rt)
      mz_tol <- 0.02
      rt_tol <- 0.5
      a <- list.files()
      b <- a[grep('.mzML',a)]
      xcms_res <- lapply(1:length(b),function(xcmsi){
        showNotification(paste0('Quantitate',b[xcmsi]),type="message",duration=360)
        raw_data <- readMSData(b[xcmsi],mode="onDisk")
        cwp <- CentWaveParam(peakwidth=c(as.numeric(input$peakwidth_left),as.numeric(input$peakwidth_right)),
                             noise=as.numeric(input$noise))
        raw_data <- findChromPeaks(raw_data,param=cwp)
        peak_table <- chromPeaks(raw_data)
        peak_table <- as.data.frame(peak_table)
        peak_table$rt <- peak_table$rt/60
        peak_table$rtmin <- peak_table$rtmin/60
        peak_table$rtmax <- peak_table$rtmax/60
        results <- data.frame(mz=numeric(),rt=numeric(),area=numeric())
        for (i in 1:nrow(user_peaks)) {
          target_mz <- user_peaks$mz[i]
          target_rt <- user_peaks$rt[i]

          # 查找候选峰
          candidates <- which(
            abs(peak_table[, "mz"] - target_mz) < mz_tol &
              abs(peak_table[, "rt"] - target_rt) < rt_tol
          )

          if (length(candidates) > 0) {
            # 选择最近的峰
            distances <- sqrt((peak_table[candidates, "mz"] - target_mz)^2 + (peak_table[candidates, "rt"] - target_rt)^2)
            closest_idx <- candidates[which.min(distances)]
            results <- rbind(results, data.frame(
              mz = target_mz,
              rt = target_rt,
              area = peak_table[closest_idx, "into"]
            ))
          } else {
            results <- rbind(results, data.frame(mz = target_mz, rt = target_rt, area = NA))
          }
        }
        # 强制提峰并计算area
        for (i in 1:nrow(results)) {
          if (is.na(results$area[i])) {
            target_mz <- results$mz[i]
            target_rt <- results$rt[i]

            # 查找附近的峰
            candidates <- which(
              abs(peak_table[, "mz"] - target_mz) < mz_tol &
                abs(peak_table[, "rt"] - target_rt) < rt_tol
            )

            if (length(candidates) > 0) {
              # 选择最近的峰
              distances <- sqrt((peak_table[candidates, "mz"] - target_mz)^2 + (peak_table[candidates, "rt"] - target_rt)^2)
              closest_idx <- candidates[which.min(distances)]

              # 重新计算面积（假设使用梯形积分法计算面积）
              area <- trapz(peak_table$rt[closest_idx:(closest_idx+1)], peak_table$into[closest_idx:(closest_idx+1)])

              # 更新area
              results$area[i] <- area
            }
          }
        }
        return(results$area)
      })
      xcms_res <- do.call(cbind,xcms_res)
      colnames(xcms_res) <- gsub('_final_output.csv','',b)
      user_peaks <- read.csv('Merged annotations.csv')
      b23 <- cbind(user_peaks,xcms_res)
      write.csv(b23,'Quantitative and annotations.csv',row.names=F)
      # 隐藏气泡提示并显示完成对话框
      shinyjs::hide("status_bubble")
      showModal(modalDialog(
        title = "Analysis Complete",
        paste0("The analysis is complete. Processed files are in:\n", params$folder_path),
        easyClose = TRUE,
        footer = NULL
      ))
    })
  }
  # 定性二
  {
    # 监听文件夹路径输入
    observeEvent(input$folder_path_ead, {
      folder <- input$folder_path_ead  # 获取用户输入的路径
      if (dir.exists(folder)) {
        params$folder_path <- folder  # 保存有效的文件夹路径
        # 查找 .mzML 文件
        mzml_files <- list.files(folder, pattern = "\\.mzML$", full.names = TRUE)
        params$mzml_files <- mzml_files
        output$selected_folder <- renderText({
          paste("Selected folder:", folder, "\nFound .mzML files:", length(mzml_files))
        })
        message("Valid folder selected: ", folder, " with ", length(mzml_files), " .mzML files.")
      } else {
        params$folder_path <- NULL
        params$mzml_files <- NULL
        output$selected_folder <- renderText("Invalid folder path. Please check and try again.")
        message("Invalid folder path: ", folder)
      }
    })

    # 输出选中的文件夹路径
    output$selected_folder <- renderText({
      if (!is.null(params$folder_path)) {
        paste("Selected folder: ", params$folder_path, "\nFound .mzML files: ", length(params$mzml_files))
      } else {
        "No folder selected"
      }
    })

    # 监听 .rda 文件上传
    observeEvent(input$rda_file_ead, {
      req(input$rda_file_ead)  # 确保文件已上传
      params$rda_file <- input$rda_file_ead  # 存储上传文件的路径
      message("Uploaded .rda file: ", input$rda_file_ead)
    })

    # 监听开始按钮点击事件
    observeEvent(input$start_button_ead, {
      # 验证所有输入参数
      showNotification("Verify if all the required R packages are installed.",type="message",duration=360)
      required_packages <- c("shinyFiles", "shinyjs", "tidyverse", "dplyr", "tidyr")

      # 自动检查并安装缺失的包
      for (package in required_packages) {
        if (!require(package, character.only = TRUE)) {
          install.packages(package, dependencies = TRUE)  # 安装缺失的包
          library(package, character.only = TRUE)         # 加载包
        } else {
          library(package, character.only = TRUE)         # 如果已安装，直接加载包
        }
      }
      library(shinyFiles)  # 加载 shinyFiles 包
      library(shinyjs)     # 用于显示和隐藏气泡提示
      library(tidyverse)
      library(dplyr)
      library(tidyr)
      req(params$folder_path, params$mzml_files, params$rda_file)
      req(input$abundance_filter_ead, input$ion_mode_ead, input$ms1_tolerance_ead, input$ms2_tolerance_ead)
      showNotification("Waiting for package loading...",type="message",duration=360)
      setwd(paste0(.libPaths(),'/','LipidIN'))
      source(paste('p1.R',sep=''))
      source(paste('pathway.R',sep=''))
      sourceCpp(paste('EQ.cpp',sep=''))
      sourceCpp(paste('EQ_support.cpp',sep=''))
      sourceCpp(paste('calculateMolecularMass.cpp',sep=''))
      sourceCpp(paste('rawmzcluster.cpp',sep=''))
      sourceCpp(paste('removeRowsWithinError.cpp',sep=''))
      sourceCpp(paste('sortMatrixByRow.cpp',sep=''))
      # 设置工作目录到选择的文件夹
      setwd(params$folder_path)
      showNotification(paste0("Working directory set to: ", params$folder_path),type="message",duration=360)


      # 显示任务状态提示
      shinyjs::show("status_bubble")
      shinyjs::html("status_bubble", "Processing... Please wait.")
      # 遍历 .mzML 文件并处理
      for (ii in params$mzml_files) {
        message("Processing file: ", ii)
        tryCatch({
          # 假设 part1_RaMS 支持直接处理路径
          part1_RaMS(ii,
                     ESImode = input$ion_mode_ead,
                     MS2_filter = input$abundance_filter_ead)
          showNotification(paste0("Successfully processed file: ", ii),type="message",duration=360)
        }, error = function(e) {
          showNotification(paste0("Error processing file: ", ii),type="error",duration=360)
        })
      }

      # 加载谱库
      shinyjs::show("status_bubble")
      shinyjs::html("status_bubble", "Reading Spectral Library... Please wait.")
      showNotification("Loading spectral library...",type="message",duration=360)
      tryCatch({
        load(params$rda_file)  # 加载 .rda 文件
        showNotification("Successfully loaded spectral library.",type="message",duration=360)
      }, error = function(e) {
        showNotification("Error loading spectral library.",type="message",duration=360)
      })
      ESI <- 'p'
      FN1 <- list.files()
      FN1 <- FN1[grep('.rda',FN1)]
      compare <- new(Comparator)
      ppm1 <- input$ms1_tolerance_ead
      ppm2 <- input$ms2_tolerance_ead
      compare$Load(NULL,count.data.frame$MZ,ppm1,ppm2,count.list)
      message("Output file name: ",params$folder_path)
      setwd(params$folder_path)
      showNotification("Starting MS2 querting...",type="message",duration=360)
      for(ii in FN1){
        print(ii)
        FNIII <- ii
        cat("\033[32m",paste('Match files ',FNIII,sep=''),"\n\033[0m")
        load(FNIII)
        cat("\033[32m",paste('Success load ',FNIII,sep=''),"\n\033[0m")
        sample_mz <- purrr::map(.x=neg.list, .f=function(x){
          return(x$PrecursorMZ)
        }) %>% unlist()
        neg.list <- neg.list[order(sample_mz)]
        neg.list <- lapply(1:length(neg.list), function(i){
          neg.list[[i]][["num"]] <- as.character(neg.list[[i]][["num"]])
          return(neg.list[[i]])
        })
        # NPG-MS2 --------------------------------------------------------------------
        # 构造函数
        # compare <- new(Comparator)
        # # 加载数据
        # # par-1:sample_list , par-2:library_mz , par-3:ms1_ppm , par-4:ms2_ppm , par-5:library_list
        # compare$Load(neg.list,count.data.frame$MZ,ppm1,ppm2,count.list)
        compare$Load2(neg.list,ppm1,ppm2)
        # 比较谱图
        compare$Compare()
        # 输出csv文件
        compare$OutputCsv(paste(gsub('.rda','',FNIII),'_NPG_5ppm.csv',sep=''))
        cat("\033[32m",paste('Result processed ',FNIII,sep=''),"\n\033[0m")
        # da <- read.csv("D:/bio_inf/LipidINDesk/test EAD/QC_EAD_treated_NPG_5ppm.csv")
        da <- read.csv(paste(gsub('.rda','',FNIII),'_NPG_5ppm.csv',sep=''))
        # dict$chain <- gsub(':0',':0(delta 0)',dict$chain)
        da <- da[which(da$score1==1),]
        colnames(da) <- c('Peak.num','mz','rt','intensity',
                          'title','score.match','score.ratio')
        library(tidyverse)
        output <- da
        d.temp <- output
        d.temp <- separate(d.temp,title,c('t','title'),sep='DB#: ')
        d.temp <- subset(d.temp,select=-t)
        d.temp <- separate(d.temp, title, c('level','title'), sep = '_DES_')
        d.temp <- separate(d.temp, title, c('title', 'other'), sep = '-Fomula-')
        d.temp <- separate(d.temp, other, c('Fomula', 'CCS'), sep = '-CCS-')
        d.temp <- separate(d.temp, CCS, c('CCS', 'Adduct'), sep = '-Add-')
        da <- d.temp
        d1 <- da[which(da$Adduct=='[M+NH4]+'),]
        d1_sn <- d1[grep('TG_sn',d1$title),]
        d1_cc <- d1[grep('TG_cc',d1$title),]
        # 统计l1/l2、l3都有的词条
        d1_sn_l1 <- unique(gsub('\\(.*','',d1_sn[which(d1_sn$level=='LEVEL1'),]$title))
        d1_sn_l2 <- unique(gsub('\\(.*','',d1_sn[which(d1_sn$level=='LEVEL2'),]$title))
        d1_sn_l3 <- unique(gsub('\\(.*','',d1_sn[which(d1_sn$level=='LEVEL3'),]$title))
        c1 <- unique(c(d1_sn_l1,d1_sn_l2))
        c_intersect <- intersect(c1,d1_sn_l3)
        d1_sn <- d1_sn[which(gsub('\\(.*','',d1_sn$title)%in%c_intersect),]
        peak.num <- unique(d1_sn$Peak.num)
        # 每个峰下的鉴定结果拼接sn异构
        res1 <- lapply(1:length(peak.num),function(i){
          # print(i)
          d.temp <- d1_sn[which(d1_sn$Peak.num==peak.num[i]),]
          d.temp <- unique(gsub('\\(.*','',d.temp$title))
          total_cu <- gsub('.* ','',gsub('_CAH_.*','',d.temp[1]))
          d.temp <- gsub('\\(.*','',gsub('.*_CAH_','',d.temp))
          d.temp <- as.data.frame(t(combn(c(d.temp,d.temp),2)))
          d.temp <- as.data.frame(t(apply(d.temp,1,sort)))
          d.temp <- d.temp[!duplicated(d.temp),]
          d.left_1 <- as.numeric(gsub(':.*','',total_cu))-
            as.numeric(gsub(':.*','',d.temp[,1]))-
            as.numeric(gsub(':.*','',d.temp[,2]))
          d.left_2 <- as.numeric(gsub('.*:','',total_cu))-
            as.numeric(gsub('.*:','',d.temp[,1]))-
            as.numeric(gsub('.*:','',d.temp[,2]))
          d.can <- which(d.left_1>=0&d.left_2>=0)
          if(length(d.can)>0){
            k <- d1_sn[which(d1_sn$Peak.num==peak.num[i]),]
            d.final <- data.frame(k[1,1:3],
                                  x1=d.temp[d.can,]$V1,
                                  x2=paste(d.left_1[d.can],d.left_2[d.can],sep=':'),
                                  x3=d.temp[d.can,]$V2)
            return(d.final)
          }
        })
        res1 <- do.call(rbind,res1)
        # 拼接l4的双键位置异构
        pn <- unique(res1$Peak.num)
        d1_cc <- d1_cc[which(d1_cc$Peak.num%in%pn),]
        # 双键位置使用LipidMaps过滤
        # cc <- gsub('\\(','(delta ',gsub('_doubleC_',',',gsub('.*_CAH_','',d1_cc$title)))
        # d1_cc <- d1_cc[which(cc%in%dict$chain),]
        res2 <- lapply(1:length(pn),function(i){
          # print(i)
          d.temp <- d1_cc[which(d1_cc$Peak.num==pn[i]),]
          d_res1 <- res1[which(res1$Peak.num==pn[i]),]
          res21 <- lapply(1:nrow(d_res1),function(j){
            # 先看看有没有交集
            sn <- as.character(d_res1[j,4:6])
            cc <- gsub('\\(.*','',gsub('.*_CAH_','',d.temp$title))
            if(length(intersect(cc,sn))==length(unique(sn))){
              # print(c(i,j))
              d_1 <- d.temp[which(cc%in%sn),]
              d_1 <- data.frame(Chain=gsub('\\(.*','',gsub('.*_CAH_','',d_1$title)),
                                CC=gsub('.*\\(','',d_1$title),int=d_1$score.ratio)
              d_1$CC <- paste('(delta',gsub('_doubleC_',',',d_1$CC),sep=' ')
              d_1$Compand <- paste(d_1$Chain,d_1$CC,sep='')
              c1 <- d_1[which(d_1$Chain==sn[1]),]
              c2 <- d_1[which(d_1$Chain==sn[2]),]
              c3 <- d_1[which(d_1$Chain==sn[3]),]
              combinations <- expand.grid(1:nrow(c1),1:nrow(c2),1:nrow(c3))
              mc <- do.call(rbind,lapply(1:nrow(combinations),function(ci){
                kk <- paste(c1[combinations[ci,1],4],'_sn2-',
                            c2[combinations[ci,2],4],'_',
                            c3[combinations[ci,3],4],sep='')
                kk <- gsub('\\(delta 0\\)','',kk)
                return(kk)
              }))
              mi <- do.call(rbind,lapply(1:nrow(combinations),function(ci){
                kk <- data.frame(int1=c1[combinations[ci,1],3],
                                 int2=c2[combinations[ci,2],3],
                                 int3=c3[combinations[ci,3],3])
              }))
              mic <- data.frame(compand=mc,mi)
              return(mic)
            }
          })
          res21 <- do.call(rbind,res21)
          if(is.null(res21)==F){
            res21 <- res21[!duplicated(res21),]
            res21$sum_int <- as.numeric(apply(res21[,-1],1,sum))
            res21 <- data.frame(d.temp[1,1:3],
                                Title=gsub('TG_cc','TG',gsub('_CAH_.*','',d.temp[1,]$title)),
                                res21)
            return(res21)
          }
        })
        res2 <- do.call(rbind,res2)
        write.csv(res2,paste(gsub('.rda','',FNIII),'_part1_result.csv',sep=''))
      }
      showNotification("Starting LCI retention time prediction and judgment...",type="message",duration=360)
      rm(count.data.frame,count.list)
      setwd(input$folder_path_ead)
      a <- list.files()
      b <- a[grep('.csv',a)]
      b <- b[-grep('final_output.csv',b)]
      file.remove(b)
      # 隐藏气泡提示并显示完成对话框
      shinyjs::hide("status_bubble")
      showModal(modalDialog(
        title = "Analysis Complete",
        paste0("The analysis is complete. Processed files are in:\n", params$folder_path),
        easyClose = TRUE,
        footer = NULL
      ))
    })
  }
}
