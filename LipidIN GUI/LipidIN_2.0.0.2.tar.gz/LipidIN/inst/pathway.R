# 3. 准备环形图比例数据
# proportions <- data.frame(
#   name = rep(nodes$name, each = 3),
#   category = rep(c("Up-regulated", "Down-regulated", "Unchanged"), length(nodes$name)),
#   value = c(50, 30, 20,
#             40, 30, 30,
#             60, 25, 15,
#             50, 30, 20,
#             40, 30, 30,
#             60, 25, 15,
#             60, 25, 15,
#             5,20,75,
#             20,0,80,
#             40, 30, 30,
#             60, 25, 15,
#             60, 25, 15,
#             5,20,75,
#             50,0,50,
#             0,50,50)  # 环形图比例数据
# )
# write.csv(proportions,'D:/bio_inf/LipidINDesk/test/pathway.csv',row.names = F)
draw_pathway <- function(data,output_path,R_file){
  # R_file <- 'D:/bio_inf/LipidINDesk/LipidIN/R'
  # proportions <- read.csv('D:/bio_inf/LipidINDesk/test/pathway.csv')
  # 1. 读取 PDF 文件并获取图像信息
  pdf_file <- paste0(R_file,'/',"Lipid pathway.pdf")
  background_pdf <- image_read_pdf(pdf_file)
  # 获取 PDF 的宽度和高度
  pdf_info <- image_info(background_pdf)
  pdf_width <- pdf_info$width
  pdf_height <- pdf_info$height
  # 2. 准备代谢物节点和位置数据
  {
    nodes <- data.frame(
      name = c("LPA", "PA", "DG", "TG", "FA", "Cer", "SM",
               'LPE','CE',
               'PE','PS','PG','PI',
               'PC','LPC'),
      x = c(278, 434, 585, 737, 892, 1524, 1679,
            180,890,
            225,355,440,525,
            296,455),
      y = c(600, 600, 600, 600, 600, 600, 600,
            460,430,
            310,310,310,310,
            140,108)
    )
  }
  # 4. 绘制基础图，添加背景 PDF 并设置坐标轴范围
  scale_factor <- 0.95  # 缩放比例
  pdf_bg <- ggplot() +
    # 添加背景 PDF 图像，缩放背景图但不改变坐标轴
    annotation_custom(
      rasterGrob(
        background_pdf,
        width = unit(scale_factor, "npc"),  # 设置宽度缩放
        height = unit(scale_factor, "npc") # 设置高度缩放
      ),
      xmin = 0, xmax = pdf_width, ymin = 0, ymax = pdf_height
    ) +
    # 坐标轴范围与 PDF 尺寸一致
    scale_x_continuous(limits = c(0, pdf_width)) +
    scale_y_continuous(limits = c(0, pdf_height)) +
    coord_fixed() +  # 保持长宽比例
    theme_void()     # 去掉多余的主题元素
  # 5. 添加环形图
  for (i in 1:nrow(nodes)) {
    node <- nodes[i, ]
    prop <- proportions[proportions$name == node$name, ]

    # 计算环形图角度
    prop$end_angle <- cumsum(prop$value) / sum(prop$value) * 2 * pi
    prop$start_angle <- c(0, head(prop$end_angle, -1))
    prop$x <- node$x
    prop$y <- node$y

    # 绘制环形图
    pdf_bg <- pdf_bg +
      geom_arc_bar(data = prop, aes(x0 = x, y0 = y, r0 = 20, r = 40,
                                    start = start_angle, end = end_angle, fill = category))+
      theme(
        legend.position = c(0.8, 0.3),
        legend.title = element_blank(),
        legend.background = element_blank(),
        legend.text = element_text(face = "bold", size = 8, color = "black")
      )
  }
  pdf_bg <- pdf_bg +
    scale_fill_manual(
      values = c("Up-regulated" = "#E64B35FF", "Down-regulated" = "#3C5488FF", "Unchanged" = "gray80")
    )
  # 6. 输出最终图像
  ggsave(paste0(output_path,'/','output_pathway.pdf'), pdf_bg, width = 10, height = 6)
}



