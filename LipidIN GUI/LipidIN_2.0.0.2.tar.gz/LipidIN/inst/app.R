# inst/app.R
setwd(paste0(.libPaths(),'/','LipidIN'))
packages <- c(
  "this.path", "shinyjs", "RaMS", "Rcpp", "tidyverse", "dplyr", "shiny",
  "golem", "shinydashboard", "ggplot2", "ggforce", "magick", "grid",
  "tidyr", "shinyFiles"
)

# checking loss package
install_missing_packages <- function(pkg) {
  missing <- pkg[!(pkg %in% installed.packages()[, "Package"])]
  if (length(missing) > 0) {
    install.packages(missing, dependencies = TRUE)
  }
}

# install all packages
install_missing_packages(packages)

# library all packages
lapply(packages, library, character.only = TRUE)
library(this.path)
library(shinyjs)
library(RaMS)
library(Rcpp)
library(tidyverse)
library(dplyr)
library(shiny)
library(golem)
library(shinydashboard)
library(ggplot2)
library(ggforce)
library(magick)
library(grid)
library(tidyr)
library(shinyFiles)
source(paste('p1.R',sep=''))
source(paste('pathway.R',sep=''))
sourceCpp(paste('EQ.cpp',sep=''))
sourceCpp(paste('EQ_support.cpp',sep=''))
sourceCpp(paste('calculateMolecularMass.cpp',sep=''))
sourceCpp(paste('rawmzcluster.cpp',sep=''))
sourceCpp(paste('removeRowsWithinError.cpp',sep=''))
sourceCpp(paste('sortMatrixByRow.cpp',sep=''))
# 加载 UI 和 server 函数
shiny::addResourcePath("www",paste0(.libPaths()[1],'/','LipidIN/www'))
source("app_ui.R")
source("app_server.R")

# 启动应用
options(shiny.maxRequestSize = 1000000 * 1024^2)
shinyApp(ui=app_ui,server=app_server)
